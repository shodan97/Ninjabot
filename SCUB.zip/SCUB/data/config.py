admins = [5319796673]

api_id = 21019959
api_hash = '5a3c4e413cf4d8bfd91203a1f1aa4c07'

